﻿using System;
using System.Collections.Generic;

namespace SampleAPI.Helper
{
    /// <summary>
    /// 
    /// </summary>
    public static class HolidayDetails
    {
        public static readonly Dictionary<DateTime, string> Holidays = new()
        {
            { new DateTime(DateTime.UtcNow.Year, 1, 1), "New Year's Day" },
            { new DateTime(DateTime.UtcNow.Year, 12, 25), "Christmas Day" },
            { new DateTime(DateTime.UtcNow.Year, 8, 15), "Independence Day" },
        };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static bool IsHoliday(DateTime date)
        {
            return Holidays.ContainsKey(date.Date);
        }
    }

}