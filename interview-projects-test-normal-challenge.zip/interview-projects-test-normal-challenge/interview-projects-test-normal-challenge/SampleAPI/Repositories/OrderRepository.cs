﻿using Microsoft.EntityFrameworkCore;
using SampleAPI.Entities;
using SampleAPI.Helper;
using SampleAPI.Requests;

namespace SampleAPI.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly List<Order> _orders = new(); 

        public async Task<List<Order>> GetRecentOrdersAsync()
        {            
            return await Task.FromResult(_orders
                .Where(o => !o.IsDeleted && o.EntryDate >= DateTime.UtcNow.AddDays(-1))
                .OrderByDescending(o => o.EntryDate)
                .ToList());
        }

        public async Task AddOrderAsync(Order order)
        {          
            _orders.Add(order);
            await Task.CompletedTask; 
        }

        public async Task<List<Order>> GetOrdersByDaysAsync(int days)
        {
            var cutoffDate = DateTime.UtcNow.AddDays(-days);
            var orders = _orders.Where(o => o.EntryDate > cutoffDate && !o.IsDeleted).ToList();
            var adjustedOrders = AdjustForWeekendsAndHolidays(orders, days);

            return await Task.FromResult(adjustedOrders);
        }

        /// <summary>
        /// Exclude weekends and holidays
        /// </summary>
        /// <param name="orders"></param>
        /// <param name="days"></param>
        /// <returns></returns>
        private List<Order> AdjustForWeekendsAndHolidays(List<Order> orders, int days)
        {          
            var result = new List<Order>();
            var today = DateTime.UtcNow;
            var daysCounted = 0;

            for (var date = today.AddDays(-days); daysCounted < days; date = date.AddDays(1))
            {               
                if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday || HolidayDetails.IsHoliday(date))
                {
                    continue;
                }

                var dailyOrders = orders.Where(o => o.EntryDate.Date == date.Date);
                result.AddRange(dailyOrders);
                daysCounted++;
            }

            return result;
        }
    }
}
