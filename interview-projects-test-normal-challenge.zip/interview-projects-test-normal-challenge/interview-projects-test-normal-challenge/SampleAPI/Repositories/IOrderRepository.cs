﻿using SampleAPI.Entities;
using SampleAPI.Requests;

namespace SampleAPI.Repositories
{
    public interface IOrderRepository
    {
        // TODO: Create repository methods.

        /// <summary>
        /// Retrieves a list of recent orders that are not deleted and within the last day.
        /// </summary>
        /// <returns>A list of recent orders.</returns>
        Task<List<Order>> GetRecentOrdersAsync();

        /// <summary>
        /// Adds a new order to the repository.
        /// </summary>
        /// <param name="order">The order to be added.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task AddOrderAsync(Order order);
        /// <summary>
        /// To get orders based on the number of days
        /// </summary>
        /// <param name="days"></param>
        /// <returns></returns>
        Task<List<Order>> GetOrdersByDaysAsync(int days);
    }
}
