﻿using System.ComponentModel.DataAnnotations;

namespace SampleAPI.Requests
{
    public class CreateOrderRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [Required(ErrorMessage = "Order name is required.")]
        [MaxLength(100, ErrorMessage = "Order name cannot exceed 100 characters.")]
        public string Name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [Required(ErrorMessage = "Order description is required.")]
        [MaxLength(100, ErrorMessage = "Order description cannot exceed 100 characters.")]
        public string Description { get; set; }
    }
}
