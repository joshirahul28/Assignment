﻿using System.ComponentModel.DataAnnotations;

namespace SampleAPI.Entities
{
    public class Order
    {
        /// <summary>
        /// 
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [Required]
        [MaxLength(100)]       
        public string Name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [Required]
        [MaxLength(100)]
        public string Description { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime EntryDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool IsInvoiced { get; set; } = true;

        /// <summary>
        /// 
        /// </summary>
        public bool IsDeleted { get; set; } = false;
    }
}
