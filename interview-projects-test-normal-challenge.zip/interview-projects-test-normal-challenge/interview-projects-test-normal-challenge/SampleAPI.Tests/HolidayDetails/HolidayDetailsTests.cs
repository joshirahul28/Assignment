﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SampleAPI.Tests.HolidayDetails
{
    public class HolidayDetailsTests
    {
        [Fact]
        public void IsHoliday_Test()
        {
            // Arrange
            var date = new DateTime(2024, 7, 4);

            // Assert
            Assert.False(Helper.HolidayDetails.IsHoliday(date));
        }

    }
}
