using FluentAssertions;
using FluentAssertions.Extensions;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;

namespace SampleAPI.Tests.Repositories
{
    public class OrderRepositoryTests
    {
        private readonly OrderRepository _orderRepository;

        public OrderRepositoryTests()
        {
            // Initialize the OrderRepository with an empty in-memory list of orders.
            _orderRepository = new OrderRepository();
        }

        [Fact]
        public async Task GetRecentOrdersAsync_ReturnsOnlyRecentOrders()
        {
            // Arrange
            var orders = new List<Order>
            {
                new Order { Id = 1, Name = "Order1", Description = "Description1", EntryDate = DateTime.UtcNow.AddHours(-1), IsDeleted = false },
                new Order { Id = 2, Name = "Order2", Description = "Description2", EntryDate = DateTime.UtcNow.AddHours(-2), IsDeleted = false },
                new Order { Id = 3, Name = "Order3", Description = "Description3", EntryDate = DateTime.UtcNow.AddDays(-3), IsDeleted = true } // Deleted order
            };

            // Adding orders to the repository
            foreach (var order in orders)
            {
                await _orderRepository.AddOrderAsync(order);
            }

            // Act
            var recentOrders = await _orderRepository.GetRecentOrdersAsync();

            // Assert
            Assert.Equal(2, recentOrders.Count); // Only 2 orders should be recent and not deleted
            Assert.All(recentOrders, order => Assert.False(order.IsDeleted)); // Ensure no deleted orders are included
        }

        [Fact]
        public async Task AddOrderAsync_AddsNewOrder()
        {
            // Arrange
            var newOrder = new Order { Name = "New Order", Description = "New Description", EntryDate = DateTime.UtcNow };

            // Act
            await _orderRepository.AddOrderAsync(newOrder);
            var recentOrders = await _orderRepository.GetRecentOrdersAsync();

            // Assert
            Assert.Contains(newOrder, recentOrders); // Check if the new order is in the list
            Assert.Equal(DateTime.UtcNow.Date, newOrder.EntryDate.Date); // Verify EntryDate is set to current UTC date
        }

        [Fact]
        public async Task GetOrdersByDaysAsync_ReturnsOrdersWithinDaysExcludingDeleted()
        {
            // Arrange
            var orders = new List<Order>
            {
                new Order { Id = 1, Name = "Order1", Description = "Description1", EntryDate = DateTime.UtcNow.AddDays(-1), IsDeleted = false },
                new Order { Id = 2, Name = "Order2", Description = "Description2", EntryDate = DateTime.UtcNow.AddDays(-2), IsDeleted = false },
                new Order { Id = 3, Name = "Order3", Description = "Description3", EntryDate = DateTime.UtcNow.AddDays(-3), IsDeleted = true } // Deleted order
            };

            // Adding orders to the repository
            foreach (var order in orders)
            {
                await _orderRepository.AddOrderAsync(order);
            }

            // Act
            var retrievedOrders = await _orderRepository.GetOrdersByDaysAsync(5);
            int count = 0;
            for (int i = 1; i < 4; i++)
            {
                if (DateTime.UtcNow.AddDays(-i).DayOfWeek == DayOfWeek.Saturday || DateTime.UtcNow.AddDays(-i).DayOfWeek == DayOfWeek.Sunday)
                {
                    count++;
                }
            }
            // Assert
            Assert.Equal(3-count, retrievedOrders.Count); // Should only return the 2 active orders
            Assert.All(retrievedOrders, order => Assert.False(order.IsDeleted)); // Ensure no deleted orders are returned
        }

        [Fact]
        public async Task GetOrdersByDaysAsync_ExcludesWeekends()
        {
            // Arrange
            var orders = new List<Order>
            {
                new Order { Id = 1, Name = "Order1", Description = "Description1", EntryDate = DateTime.UtcNow.AddDays(-1), IsDeleted = false },
                new Order { Id = 2, Name = "Order2", Description = "Description2", EntryDate = DateTime.UtcNow.AddDays(-2), IsDeleted = false },
                new Order { Id = 3, Name = "Order3", Description = "Description3", EntryDate = DateTime.UtcNow.AddDays(-3), IsDeleted = false } 
            };

            // Adding orders to the repository
            foreach (var order in orders)
            {
                await _orderRepository.AddOrderAsync(order);
            }

            // Act
            var retrievedOrders = await _orderRepository.GetOrdersByDaysAsync(3);
            int count=0;
            for(int i=1;i<4;i++)
            {
                if(DateTime.UtcNow.AddDays(-i).DayOfWeek == DayOfWeek.Saturday || DateTime.UtcNow.AddDays(-i).DayOfWeek == DayOfWeek.Sunday)
                {
                    count++;
                }
            }
            
                // Assert
                Assert.Equal(3-count, retrievedOrders.Count); // Should return only the 2 orders that are not on a weekend
        }

    }
}