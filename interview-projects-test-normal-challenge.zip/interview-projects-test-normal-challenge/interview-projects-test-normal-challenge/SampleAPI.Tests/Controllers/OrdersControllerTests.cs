﻿using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using SampleAPI.Controllers;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;

namespace SampleAPI.Tests.Controllers
{
    public class OrdersControllerTests
    {
        private readonly Mock<IOrderRepository> _mockOrderRepository;
        private readonly OrdersController _controller;

        public OrdersControllerTests()
        {
            _mockOrderRepository = new Mock<IOrderRepository>();
            _controller = new OrdersController(_mockOrderRepository.Object);
        }

        [Fact]
        public async Task GetOrders_ReturnsOkResult_WithRecentOrders()
        {
            // Arrange
            var orders = new List<Order>
            {
                new Order { Id = 1, Name = "Order1", Description = "Description1", EntryDate = DateTime.UtcNow },
                new Order { Id = 2, Name = "Order2", Description = "Description2", EntryDate = DateTime.UtcNow.AddHours(-1) }
            };

            _mockOrderRepository.Setup(repo => repo.GetRecentOrdersAsync()).ReturnsAsync(orders);

            // Act
            var result = await _controller.GetOrders();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnOrders = Assert.IsType<List<Order>>(okResult.Value);
            Assert.Equal(2, returnOrders.Count);
        }

        [Fact]
        public async Task GetOrders_ReturnsInternalServerError_WhenExceptionThrown()
        {
            // Arrange
            _mockOrderRepository.Setup(repo => repo.GetRecentOrdersAsync()).ThrowsAsync(new Exception("Database error"));

            // Act
            var result = await _controller.GetOrders();

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(StatusCodes.Status500InternalServerError, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task CreateOrder_ValidRequest_ReturnsCreatedResult()
        {
            // Arrange
            var request = new CreateOrderRequest { Name = "New Order", Description = "New Description" };

            // Act
            var result = await _controller.CreateOrder(request);

            // Assert
            var createdResult = Assert.IsType<CreatedAtActionResult>(result.Result);
            Assert.Equal(StatusCodes.Status201Created, createdResult.StatusCode);
        }

        [Fact]
        public async Task CreateOrder_InvalidRequest_ReturnsBadRequest()
        {
            // Arrange
            var request = new CreateOrderRequest { Name = "", Description = "" }; // Invalid request

            // Act
            var result = await _controller.CreateOrder(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Invalid order data.", badRequestResult.Value);
        }

        [Fact]
        public async Task GetOrdersByDays_ValidDays_ReturnsOkResult_WithOrders()
        {
            // Arrange
            var days = 5;
            var orders = new List<Order>
            {
                new Order { Id = 1, Name = "Order1", Description = "Description1", EntryDate = DateTime.UtcNow.AddDays(-2) },
                new Order { Id = 2, Name = "Order2", Description = "Description2", EntryDate = DateTime.UtcNow.AddDays(-3) }
            };

            _mockOrderRepository.Setup(repo => repo.GetOrdersByDaysAsync(days)).ReturnsAsync(orders);

            // Act
            var result = await _controller.GetOrdersByDays(days);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnOrders = Assert.IsType<List<Order>>(okResult.Value);
            Assert.Equal(2, returnOrders.Count);
        }

        [Fact]
        public async Task GetOrdersByDays_InvalidDays_ReturnsBadRequest()
        {
            // Arrange
            int days = 0; // Invalid days

            // Act
            var result = await _controller.GetOrdersByDays(days);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Nmber of days must be greater than zero.", badRequestResult.Value);
        }
    }
}
